#!/usr/bin/env python3
"""Preflight for the Basement Descent design sheets.

Run it before every build. It lays each sheet's rows over its columns and lists:
  - rows with a missing or extra column
  - references between sheets that do not resolve
  - unfilled cells (null) in the sheets and in design.json

A reference is a string like "monsters:fly", or "items:*" for every row.
Build only when the last line says "clean".
"""
import json
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
design = json.loads((root / "design.json").read_text(encoding="utf-8"))

sheets = {}
for file_name in design.get("sheets", []):
    path = root / file_name
    if not path.exists():
        print(f"missing sheet file: {file_name}")
        sys.exit(1)
    data = json.loads(path.read_text(encoding="utf-8"))
    sheets[data["sheet"]] = data

ref_pattern = re.compile(r"^(%s):(.+)$" % "|".join(re.escape(name) for name in sheets))
shape, broken, unfilled = [], [], []


def walk(value, where, path):
    if value is None:
        unfilled.append(f"{where}  {path}")
    elif isinstance(value, dict):
        for key, item in value.items():
            walk(item, where, f"{path}.{key}" if path else key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            walk(item, where, f"{path}[{index}]")
    elif isinstance(value, str):
        match = ref_pattern.match(value)
        if match:
            target, wanted = match.groups()
            ids = {row["id"] for row in sheets[target]["rows"]}
            resolves = bool(ids) if wanted == "*" else wanted in ids
            if not resolves:
                broken.append(f"{where}  {path} -> {value}")


walk(design, "design.json", "")
for name, data in sheets.items():
    columns = data["columns"]
    for row in data["rows"]:
        where = f"{name}/{row.get('id', '?')}"
        for column in columns:
            if column not in row:
                shape.append(f"{where}  missing column {column}")
        for column in row:
            if column not in columns:
                shape.append(f"{where}  extra column {column}")
        for column in columns:
            if column in row:
                walk(row[column], where, column)


def show(title, items):
    print(f"{title}: {len(items)}")
    for item in items:
        print("  " + item)


show("rows that do not match their sheet's columns", shape)
show("references that do not resolve", broken)
show("unfilled cells", unfilled)

if shape or broken or unfilled:
    print("not clean - fix these, sheet first, then build")
    sys.exit(1)
print("clean")
